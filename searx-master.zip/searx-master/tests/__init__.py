import os
os.environ['SEARX_DEBUG'] = '1'
