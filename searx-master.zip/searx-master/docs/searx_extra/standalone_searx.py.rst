
.. _standalone_searx.py:

===================================
``searx_extra/standalone_searx.py``
===================================

.. automodule:: searx_extra.standalone_searx
  :members:
